let dz_username = "";
let parser = new DOMParser();
let albums = {};

message = {cmd: "", query: "", detaildict: {}}

function unEscape(a) {
    a = a.replace(/&lt;/g , "<");	 
    a = a.replace(/&gt;/g , ">");     
    a = a.replace(/&quot;/g , "\"");  
    a = a.replace(/&#39;/g , "\'");   
    a = a.replace(/&amp;/g , "&");
    return a;
}

function xml_encode(a)
{	
	
	a =	a.replace(/&/g,'&amp;amp;');
	a =	a.replace(/</g,	'&lt;');
	a =	a.replace(/>/g,	'&gt;');
	a =	a.replace(/'/g,	'&amp;apos;');
	a =	a.replace(/"/g,	'&amp;quot;');
	return a;
}		

function getUser() {
    message.cmd = "getUserInfo";
    message.detaildict = {AccountSource: "Deezer2"};
    if (dz_username === "" ) {
        chrome.runtime.sendMessage(message,function(response) {
            try {
                resp = unEscape(response);
                b = parser.parseFromString(resp,"text/xml");
                json = JSON.parse(b.getElementsByTagName('Result')[0].innerHTML);
                dz_username = json["userName"];
                if (dz_username != "") {
                    chrome.storage.sync.set({ dz_username: dz_username });
                }    
            }    
            catch(err) {};    
        }); 
    }    
}    


function getDeezerCovers(data,artists) {
    let ca = document.getElementById("covers");
    ca.innerHTML="";
    //artists = artist.split(" / ");
    
    for (i=0; i<data.length; i++) {
        if (data.length > 5) {
            let found = false;
            let artist = data[i]["artist"]["name"];
            if(!artists.includes(artist)) {
                for (j=0; j<artists.length; j++) {
                    if(artists[j].includes(artist) || artist.includes(artists[j])) {
                        found = true;
                        break;
                    }   
                }
                if(!found)
                    continue;
            }
        }            
        try {
            var div = document.createElement('div');
            div.setAttribute("class","container");
            let img = document.createElement('img');
            img.src = data[i]['cover_medium'];
            img.height = '150';
            img.width = '150';
            img.id = i;
            img.addEventListener("click",playAlbum,false);
            div.append(img);
            ca.append(div)
        } catch(err) {
            console.error(err);
        }
    }
}    


function playAlbum() {
    id = this.id;
    let list_name = albums[id]['title'];
    let item_id = albums[id]['id'];
    let node = "album";
    
    document.getElementById("covers").innerHTML = "";
    
    let xml = `<?xml version="1.0" encoding="utf-8"?> 
<PlayList><ListName>${list_name}</ListName><ListInfo> <SourceName>Deezer2</SourceName> <SearchUrl>https://5705754224.airable.io/deezer/${node}/${item_id}</SearchUrl><requestQuality>LOSSLESS</requestQuality><Login_username>${dz_username}</Login_username></ListInfo><Tracks></Tracks></PlayList>`
    
    xml = xml_encode(xml);
    
    message.cmd = "Stop";
    message.detaildict = {"InstanceID":0};
    chrome.runtime.sendMessage(message,function(response) {
        message.cmd = "createQueue";
        message.detaildict = {"QueueContext": xml};
        chrome.runtime.sendMessage(message,function(response) {
            message.cmd = "playQueueWithIndex";
            message.detaildict = {"QueueName": list_name, "Index": 0};
            chrome.runtime.sendMessage(message,function(response) {
            });

        });
    });
}    


function init() {

    try {

        let header = document.getElementById("streams");
        let headline = document.getElementById("albumHeadline");
        var btnContainer = document.getElementById("streams");
        let title = document.getElementById("albumTitle");
        
        title.setAttribute("contenteditable",true);
        
        let btn = document.createElement("button");
        btn.id = "searchbutton";
        btn.setAttribute("class","searchbtn");

        let covers = document.createElement("div");
        covers.id = "covers";
        covers.setAttribute("class","covers");
        

        btn.addEventListener('click', function() {
            data = Object.assign({},this.dataset);

            message.cmd = "search";

            let title = document.getElementById("albumTitle").innerHTML;
            let elements = document.getElementById("albumArtists").getElementsByTagName("a");
            let artists = [];
            for (let item of elements) {
                artists.push(item.innerText);
            }    
            message.query = title + " " + artists.join(" ");
            
            
            chrome.runtime.sendMessage(message, (response) => {   
                try {
                    if(response['data'].length) {
                        albums = response['data'];
                        getDeezerCovers(albums,artists);
                    } else {albums = {}};
                } catch(err) {
                    console.log(err);
                    albums = {}
                }    
            });
        });
        
        btnContainer.append(btn);
        btnContainer.parentNode.insertBefore(covers,btnContainer.nextSibling);
    } catch(error) {console.log(error);}
}

if (window.location.pathname.includes('/album/')) {
    getUser();
    init();
}    
