let parser = new DOMParser();
let currentTransportState = "PLAYING";
let coverurl = "";
const message = {cmd: "", query: "", detaildict: {}}

const toEmbed = () =>
`<div id="player" class="player">
	<div class="cover" id="cover">
        <canvas id="cv" width="256" height="600"></canvas>
    </div>
	<div class="player-ui">
		<div class="title" id="album">
			<h3></h3>
		</div>
		<div class="small" id="title">
			<p></p>
		</div>
        <div class="small" id="artist">
            <p></p>
        </div>
		<div class="controls">
            <i class="material-icons" id="openclose">keyboard_arrow_down</i>
			<i class="material-icons" id="prev">skip_previous</i>
			<i class="material-icons" id="playpause">play_arrow</i>
			<i class="material-icons" id="next">skip_next</i>
		</div>
	</div>
</div>`

if (window.location.pathname.includes('/album/')) {
    setInterval(getMeta,1000);
    getMeta();

    let lnk = document.createElement('link');
    lnk.href = "https://fonts.googleapis.com/icon?family=Material+Icons";
    lnk.rel = "stylesheet";
    document.head.append(lnk);
    
    const newNode = createPlayerNode();
    newNode.innerHTML = toEmbed();
    document.body.appendChild(newNode);
}


function createPlayerNode() {
  const newNode = document.createElement('div');
  newNode.id = 'wiim-player';

  applyStyle(newNode, {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    position: 'fixed',
    bottom: '12px',
    right: '32px',
    width: '256px',
    height: '256px',
    backgroundColor: 'black',
    color: 'white',
    zIndex: '99999',
    overflow: 'auto',
  });

  return newNode;
}

function unEscape(a) {
    a = a.replace(/&lt;/g , "<");	 
    a = a.replace(/&gt;/g , ">");     
    a = a.replace(/&quot;/g , "\"");  
    a = a.replace(/&#39;/g , "\'");   
    a = a.replace(/&amp;/g , "&");
    return a;
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}


function applyStyle(node, style) {
  Object.keys(style).forEach((it) => (node.style[it] = style[it]));
}

function getCoverart(url) {
    url = url.replace("http:","https:");
    if(url === coverurl) {
        return;
    } else {
        coverurl = url;
        var canvas = document.getElementById("cv");
        var ctx = canvas.getContext('2d');
        var img = new Image();

        img.src = coverurl;

        img.onload = function() {
            ctx.drawImage(img, 0, 0, 256, 256);

            var gradient = ctx.createLinearGradient(0,0,0,ctx.canvas.height);

            gradient.addColorStop(0, 'rgba(0,0,0,0)');
            gradient.addColorStop(1, '#000');

            ctx.fillStyle = gradient;

            ctx.fillRect(0, 0, 256, 600);
        };
        
    }
}

function getMeta() {
  message.cmd = "getStatus";
    
  chrome.runtime.sendMessage(message, (response) => {  
    b = parser.parseFromString(response, "text/xml");
    currentTransportState = b.getElementsByTagName("CurrentTransportState")[0].innerHTML;
      
    if(currentTransportState === 'PLAYING') {
        document.getElementById("playpause").innerHTML = "pause";
    } else {
        document.getElementById("playpause").innerHTML = "play_arrow";
    }    
      
    let meta = b.getElementsByTagName("TrackMetaData")[0].innerHTML;
    displayMeta(meta);  
      
  });  
    
}

function displayMeta(a){
    meta = unEscape(a)
    let title = "";
    let creator = "";
    let subtitle = "";
    let artist = "";
    let album = "";
    let url = "";
    let channel = "0";
    
    b = parser.parseFromString(meta,"text/xml");
    try {
        title = b.getElementsByTagName("dc:title")[0].innerHTML;
        if (title.length > 30) {
            title = title.substring(0,30) + "...";
        }    
        document.getElementById("title").innerHTML = "<p>"+title+"</p>";
        try {
            creator = b.getElementsByTagName("dc:creator")[0].innerHTML;
        } catch(error) {creator="";}
        
    } catch(error) {console.log(error)}
    
    try {
        subtitle = b.getElementsByTagName("dc:subtitle")[0].innerHTML;
        if (subtitle.length > 30) {
            subtitle = subtitle.substring(0,30) + "...";
        }    
            
        document.getElementById("subtitle").innerHTML = "<p>"+subtitle+"</p>";
    } catch(error) {subtitle="";}
    
    try {
        artist = b.getElementsByTagName("upnp:artist")[0].innerHTML;
        if (artist.length > 30) {
            artist = artist.substring(0,30) + "...";
        }    
        document.getElementById("artist").innerHTML = "<p>"+artist+"</p>";
    } catch(error) {artist="";}

    try {
        album = b.getElementsByTagName("upnp:album")[0].innerHTML;
        if (album.length > 22) {
            album = album.substring(0,22) + "...";
        }    
        document.getElementById("album").innerHTML = "<h3>"+album+"</h3>";
    } catch(error) {album="";}

    try {
        url = b.getElementsByTagName("upnp:albumArtURI")[0].innerHTML;
        message.cmd = "coverart";
        getCoverart(url);
    }    
    catch (error) {console.log(error)}   
    
    let depth = 16;
    try {
        depth = b.getElementsByTagName('song:format_s')[0].innerHTML;
        if(depth > 24) depth=24;
    }    
    catch (error) {console.log(error)}   
    
    let rate = 44.1;
    try {
        rate = b.getElementsByTagName('song:rate_hz')[0].innerHTML / 1000;
    }    
    catch (error) {}   

    let actualQuality = "";
    try {
        actualQuality = b.getElementsByTagName('song:actualQuality')[0].innerHTML;
        if(actualQuality === 'HD')
            depth = 16;

        if(actualQuality === 'LOSSLESS')
            actualQuality = "HiFi";
    }    
    catch (error) {}   

    let bitrate = "";
    try {
        bitrate =b.getElementsByTagName('song:bitrate')[0].innerHTML;
        if (isNaN(bitrate)) {
            bitrate = "";
        }
        else {
            bitrate = bitrate + "kbps";
        }
        
    }
    catch (error) {}   
};    

document.getElementById("prev").addEventListener("click",function(){
    message.cmd = "Prev";
    chrome.runtime.sendMessage(message,function(response) { });
});

document.getElementById("playpause").addEventListener("click",function(){
    message.cmd = 'Pause';
    if(currentTransportState != 'PLAYING') {
        message.cmd = 'Play';
    }    

    chrome.runtime.sendMessage(message,function(response) {});
});

document.getElementById("next").addEventListener("click",function(){
    message.cmd = "Next";
    chrome.runtime.sendMessage(message,function(response) { });
    getMeta();
});

document.getElementById("openclose").addEventListener("click",function(){
    let player = document.getElementById("wiim-player");
    if (player.style.height === "30px") {
        player.style.height = "256px";
        this.innerHTML = "keyboard_arrow_down";
    } else {
        player.style.height = "30px";
        player.scrollTop = player.scrollHeight;
        this.innerHTML = "keyboard_arrow_up";
    }
});

// "*://www.allmusic.com/album/*"
