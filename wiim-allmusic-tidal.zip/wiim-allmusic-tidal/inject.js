const countryCode = 'US';
const TIDAL_PUBLIC_TOKEN = 'CzET4vdadNUFQ5JU';

let parser = new DOMParser();
let albums = {};

message = {cmd: "", query: "", detaildict: {}}

function xml_encode(a)
{	
	
	a =	a.replace(/&/g,'&amp;amp;');
	a =	a.replace(/</g,	'&lt;');
	a =	a.replace(/>/g,	'&gt;');
	a =	a.replace(/'/g,	'&amp;apos;');
	a =	a.replace(/"/g,	'&amp;quot;');
	return a;
}		

function getTidalCovers(data,artist) {
    let ca = document.getElementById("covers");
    let cover = "";
    let cover_url = "";
    covers.innerHTML="";
    artists = artist.split(" / ");
    
    for (i=0; i<data.length; i++) {
        if (data.length > 5) {
            let found = false;
            let artist = data[i]["artist"]["name"];
            if(!artists.includes(artist)) {
                for (j=0; j<artists.length; j++) {
                    if(artists[j].includes(artist) || artist.includes(artists[j])) {
                        found = true;
                        break;
                    }   
                }
                if(!found)
                    continue;
            }
        }    
        
        try {
            var div = document.createElement('div');
            var divsub = document.createElement('div');
            div.setAttribute("class","container");
            divsub.setAttribute("class","bottom-centered");
            divsub.innerHTML=data[i]["audioQuality"];
            let img = document.createElement('img');
            cover = data[i]['cover'].replaceAll('-','/')
            cover_url = `https://resources.tidal.com/images/${cover}/320x320.jpg`;
            img.src = cover_url;
            img.height = '150';
            img.width = '150';
            img.id = i;
            img.addEventListener("click",playAlbum,false);
            div.append(img);
            div.append(divsub);
            ca.append(div)
        } catch(err) {
            console.error(err);
        }
    }
}    

function searchTidal(query, artist) {
    
        let url = `https://api.tidal.com/v1/search/albums?countryCode=${countryCode}&query=${query}&limit=100&offset=0&types=ALBUMS&includeContributors=true`;

        fetch(url, {headers: { 'x-tidal-token': TIDAL_PUBLIC_TOKEN },
        })
        .then(response => response.json())
        .then( response => {
            try {
                if(response['items'].length) {
                    albums = response['items'];
                    getTidalCovers(albums,artist);
                } else {albums = {}};
            } catch(err) {
                console.log(err);
                albums = {}
            }    
            
        })    
        .catch(function (err) {
            console.log(err);
        })
}

function playAlbum() {
    id = this.id;
    let list_name = albums[id]['title'];
    let item_id = albums[id]['id'];
    let node = "album";
    
    document.getElementById("covers").innerHTML = "";
    
    let xml = `<?xml version="1.0"?> 
<PlayList><ListName>${list_name}</ListName><ListInfo> <SourceName>Tidal</SourceName> <SearchUrl>https://api.tidal.com/v1/${node}s/${item_id}/tracks?countryCode=${countryCode}&offset=0&limit=50</SearchUrl><requestQuality>LOSSLESS</requestQuality></ListInfo></PlayList>`
    
    xml = xml_encode(xml);
    
    message.cmd = "createQueue";
    message.detaildict = {"QueueContext": xml}
    chrome.runtime.sendMessage(message,function(response) {});
    
    message.cmd = "playQueueWithIndex";
    message.detaildict = {"QueueName": list_name, "Index": 0};
    chrome.runtime.sendMessage(message,function(response) {});
    
}    


function init() {

    try {
        let link = document.getElementsByClassName("add-to-collection-link")[0];
        let header = document.getElementsByTagName("header")[0];
        let btnContainer = document.getElementsByClassName("button-container")[0];
        let data = Object.assign({},link['dataset']);

        let title = data["album"];
        let artist = data["artist"];
        let aid = data["id"];

        let input = document.createElement("input");
        input.id = "searchinput";
        input.type = "search";
        input.name="q";
        input.size = "30";
        input.value = title + " " + artist.split(" / ")[0];
        
        let btn = document.createElement("button");
        btn.id = "searchbutton";
        btn.innerHTML = "Search Tidal";
        btn.setAttribute("class","searchbtn");
        input.setAttribute("class","searchinput");

        let covers = document.createElement("div");
        covers.id = "covers";
        covers.setAttribute("class","covers");
        header.append(covers);

        btn.addEventListener('click', function() {
            query = input.value;
            searchTidal(query, artist);
        });
        btnContainer.append(input);
        btnContainer.append(btn);
    } catch(error) {console.log(error);}
    
}

if (window.location.pathname.includes('/album/')) {

    init();
}    
