const countryCode = 'US';
const TIDAL_PUBLIC_TOKEN = 'CzET4vdadNUFQ5JU';

let parser = new DOMParser();
let albums = {};

message = {cmd: "", query: "", detaildict: {}}

function xml_encode(a)
{	
	
	a =	a.replace(/&/g,'&amp;amp;');
	a =	a.replace(/</g,	'&lt;');
	a =	a.replace(/>/g,	'&gt;');
	a =	a.replace(/'/g,	'&amp;apos;');
	a =	a.replace(/"/g,	'&amp;quot;');
	return a;
}		

function getTidalCovers(data,artists) {
    let ca = document.getElementById("covers");
    let cover = "";
    let cover_url = "";
    ca.innerHTML="";
    
    for (i=0; i<data.length; i++) {
        if (data.length > 5) {
            let found = false;
            let artist = data[i]["artist"]["name"];
            if(!artists.includes(artist)) {
                for (j=0; j<artists.length; j++) {
                    if(artists[j].includes(artist) || artist.includes(artists[j])) {
                        found = true;
                        break;
                    }   
                }
                if(!found)
                    continue;
            }
        }    
        
        try {
            var div = document.createElement('div');
            var divsub = document.createElement('div');
            div.setAttribute("class","container");
            divsub.setAttribute("class","bottom-centered");
            divsub.innerHTML=data[i]["audioQuality"];
            let img = document.createElement('img');
            cover = data[i]['cover'].replaceAll('-','/')
            cover_url = `https://resources.tidal.com/images/${cover}/320x320.jpg`;
            img.src = cover_url;
            img.height = '150';
            img.width = '150';
            img.id = i;
            img.addEventListener("click",playAlbum,false);
            div.append(img);
            div.append(divsub);
            ca.append(div)
        } catch(err) {
            console.error(err);
        }
    }
}    

function searchTidal(query, artists) {
    
        let url = `https://api.tidal.com/v1/search/albums?countryCode=${countryCode}&query=${query}&limit=200&offset=0&types=ALBUMS&includeContributors=true`;

        fetch(url, {headers: { 'x-tidal-token': TIDAL_PUBLIC_TOKEN },
        })
        .then(response => response.json())
        .then( response => {
            try {
                if(response['items'].length) {
                    albums = response['items'];
                    getTidalCovers(albums,artists);
                } else {albums = {}};
            } catch(err) {
                console.log(err);
                albums = {}
            }    
            
        })    
        .catch(function (err) {
            console.log(err);
        })
}

function playAlbum() {
    id = this.id;
    let list_name = albums[id]['title'];
    let item_id = albums[id]['id'];
    let node = "album";
    
    document.getElementById("covers").innerHTML = "";
    list_name = list_name.replace(' & ',' ');
    
    let xml = `<?xml version="1.0"?>
<PlayList><ListName>${list_name}</ListName><ListInfo> <SourceName>Tidal</SourceName><SearchUrl>https://api.tidal.com/v1/${node}s/${item_id}/tracks?countryCode=${countryCode}&offset=0&limit=50</SearchUrl><requestQuality>LOSSLESS</requestQuality></ListInfo></PlayList>`
    
    xml = xml_encode(xml);

    message.cmd = "Stop";
    message.detaildict = {"InstanceID":0};
    chrome.runtime.sendMessage(message,function(response) {
        message.cmd = "createQueue";
        message.detaildict = {"QueueContext": xml};
        chrome.runtime.sendMessage(message,function(response) {
            message.cmd = "playQueueWithIndex";
            message.detaildict = {"QueueName": list_name, "Index": 0};
            chrome.runtime.sendMessage(message,function(response) {
            });

        });
    });
}    

function init() {

    try {
        let header = document.getElementById("streams");
        let headline = document.getElementById("albumHeadline");
        var btnContainer = document.getElementById("streams");
        let title = document.getElementById("albumTitle");
        
        title.setAttribute("contenteditable",true);
        
        let btn = document.createElement("button");
        btn.id = "searchbutton";
        btn.setAttribute("class","searchbtn");

        let covers = document.createElement("div");
        covers.id = "covers";
        covers.setAttribute("class","covers");

        btn.addEventListener('click', function() {
            let title = document.getElementById("albumTitle").innerHTML;
            let elements = document.getElementById("albumArtists").getElementsByTagName("a");
            let artists = [];
            for (let item of elements) {
                artists.push(item.innerText);
            }    
            searchTidal(title, artists);
        });
        btnContainer.append(btn);
        btnContainer.parentNode.insertBefore(covers,btnContainer.nextSibling);
                            
    } catch(error) {console.log(error);}
    
}

if (window.location.pathname.includes('/album/')) {

    init();
}    
